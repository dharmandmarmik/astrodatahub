import * as phys from "../index.js";

console.log("KE 10kg @5m/s:", phys.classical.kineticEnergy(10,5));
console.log("Circular vel Earth around Sun (1 AU):", phys.astrophysics.circularVelocity(phys.astroConstants.AU, phys.astroConstants.M_sun));
console.log("Schwarzschild radius of Sun (m):", phys.relativity.schwarzschildRadius(phys.astroConstants.M_sun));
console.log("RK4 simple test (dy/dt = -y):", phys.rk4Step ? "rk4 available" : "rk4 missing");
