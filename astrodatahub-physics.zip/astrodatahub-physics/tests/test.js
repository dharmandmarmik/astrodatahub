import { constants_fundamental } from "astrodatahub-physics";

console.log(constants_fundamental);
