//
// ─── CONSTANTS ───────────────────────────────────────────────────────────────
//
export * as constants_fundamental from "./src/constants/fundamental.js";
export * as constants_astro from "./src/constants/astro_constants.js";
export * as constants_particle from "./src/constants/particle_constants.js";
export * as constants_units from "./src/constants/unit_constants.js";

//
// ─── MECHANICS ───────────────────────────────────────────────────────────────
//
export * as kinematics from "./src/mechanics/kinematics.js";
export * as dynamics from "./src/mechanics/dynamics.js";
export * as mechanics_energy from "./src/mechanics/energy.js";
export * as rotation from "./src/mechanics/rotation.js";

//
// ─── ELECTROMAGNETISM ───────────────────────────────────────────────────────
//
export * as electrostatics from "./src/electromagnetism/electrostatics.js";
export * as magnetism from "./src/electromagnetism/magnetism.js";
export * as maxwell from "./src/electromagnetism/maxwell.js";
export * as circuits from "./src/electromagnetism/circuits.js";

//
// ─── THERMODYNAMICS ─────────────────────────────────────────────────────────
//
export * as thermal_properties from "./src/thermodynamics/thermal_properties.js";
export * as heat_transfer from "./src/thermodynamics/heat_transfer.js";
export * as stat_mechanics from "./src/thermodynamics/stat_mechanics.js";

//
// ─── RELATIVITY ─────────────────────────────────────────────────────────────
export * as special_relativity from "./src/relativity/special_relativity.js";
export * as general_relativity from "./src/relativity/general_relativity.js";
export * as spacetime from "./src/relativity/spacetime.js";

//
// ─── QUANTUM ────────────────────────────────────────────────────────────────
export * as wavefunctions from "./src/quantum/wavefunctions.js";
export * as schrodinger from "./src/quantum/schrodinger.js";
export * as operators from "./src/quantum/operators.js";
export * as quantum_constants from "./src/quantum/quantum_constants.js";

//
// ─── NUCLEAR PHYSICS ─────────────────────────────────────────────────────────
export * as decay from "./src/nuclear/decay.js";
export * as reactions from "./src/nuclear/reactions.js";
export * as radiation from "./src/nuclear/radiation.js";

//
// ─── ASTROPHYSICS ───────────────────────────────────────────────────────────
export * as stellar from "./src/astrophysics/stellar.js";
export * as orbital from "./src/astrophysics/orbital.js";
export * as cosmology from "./src/astrophysics/cosmology.js";
export * as blackholes from "./src/astrophysics/blackholes.js";

//
// ─── MATHEMATICS ────────────────────────────────────────────────────────────
export * as calculus from "./src/mathematics/calculus.js";
export * as linear_algebra from "./src/mathematics/linear_algebra.js";
export * as numerical_methods from "./src/mathematics/numerical_methods.js";
export * as statistics from "./src/mathematics/statistics.js";

//
// ─── UTILS ───────────────────────────────────────────────────────────────────
export * as unit_conversion from "./src/utils/unit_conversion.js";
export * as parser from "./src/utils/parser.js";
export * as helpers from "./src/utils/helpers.js";

//
// ─── EXPERIMENTAL ────────────────────────────────────────────────────────────
export * as plotting from "./src/experimental/plotting.js";
export * as simulation from "./src/experimental/simulation.js";
export * as data_analysis from "./src/experimental/data_analysis.js";

//
// ─── TESTS (OPTIONAL EXPORT — REMOVE IF YOU DON'T WANT IT) ───────────────────
//
export * as mechanics_test from "./tests/mechanics.test.js";
export * as quantum_test from "./tests/quantum.test.js";

