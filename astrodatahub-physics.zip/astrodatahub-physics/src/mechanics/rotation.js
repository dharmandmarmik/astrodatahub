export function momentOfInertiaPointMass(m, r) {
  return m * r * r;
}

export function angularMomentum(I, omega) {
  return I * omega;
}

export function rotationalKineticEnergy(I, omega) {
  return 0.5 * I * omega * omega;
}
