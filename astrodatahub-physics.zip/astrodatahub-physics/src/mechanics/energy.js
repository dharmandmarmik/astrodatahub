export function potentialEnergy(m, g, h) {
  return m * g * h;
}

export function springPotential(k, x) {
  return 0.5 * k * x * x;
}

export function totalEnergy(ke, pe) {
  return ke + pe;
}
