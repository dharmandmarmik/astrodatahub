export function force(m, a) {
  return m * a;
}

export function accelerationFromForce(F, m) {
  return F / m;
}

export function frictionForce(mu, N) {
  return mu * N;
}
