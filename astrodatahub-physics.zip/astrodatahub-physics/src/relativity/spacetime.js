export function minkowskiInterval(t, x, y=0, z=0, c=299792458) {
  // s^2 = -(ct)^2 + x^2 + y^2 + z^2
  return - (c*t)*(c*t) + x*x + y*y + z*z;
}
