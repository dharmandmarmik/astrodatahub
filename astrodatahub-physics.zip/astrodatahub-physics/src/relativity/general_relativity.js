import { G } from "../constants/fundamental.js";
// stub: simple Schwarzschild radius
export function schwarzschildRadius(M) {
  return (2 * G * M) / (299792458**2);
}
