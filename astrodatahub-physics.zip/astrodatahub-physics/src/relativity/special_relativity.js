import { c } from "../constants/fundamental.js";
export function gamma(v) {
  if (Math.abs(v) >= c) throw new Error("v must be < c");
  return 1 / Math.sqrt(1 - (v*v)/(c*c));
}
export function lorentzTransform(t, x, v) {
  const g = gamma(v);
  return {
    tPrime: g * (t - (v * x) / (c*c)),
    xPrime: g * (x - v * t)
  };
}
