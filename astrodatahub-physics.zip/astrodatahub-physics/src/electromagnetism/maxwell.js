// Minimal helpers for Maxwell-like relations (symbolic/utility)
export function poynting(Sx, Sy, Sz) {
  return Math.sqrt(Sx*Sx + Sy*Sy + Sz*Sz);
}
