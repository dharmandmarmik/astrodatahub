export function magneticFieldLoop(I, R) {
  // on-axis B at center of circular loop
  const mu0 = 4 * Math.PI * 1e-7;
  return (mu0 * I) / (2 * R);
}
