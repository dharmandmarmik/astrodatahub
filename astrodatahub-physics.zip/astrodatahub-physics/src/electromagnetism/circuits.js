export function ohmCurrent(V, R) { return V / R; }
export function seriesResistance(...res) { return res.reduce((a,b)=>a+b,0); }
export function parallelResistance(...res) { return 1 / res.reduce((a,b)=>a + 1/b, 0); }
