import { e } from "../constants/fundamental.js";
export function coulombForce(q1, q2, r, k = 8.9875517923e9) {
  return (k * q1 * q2) / (r * r);
}
export function electricField(q, r, k = 8.9875517923e9) {
  return (k * q) / (r * r);
}
