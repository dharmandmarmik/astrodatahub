// ─────────────────────────────────────────────────────────────
// ASTRODATAHUB — ORBITAL MECHANICS MODULE (PURE FUNCTIONS)
// Covers: Kepler’s laws, anomalies, orbital periods, velocities,
// SMA, eccentricity, energy, angular momentum, Δv, transfer orbits
// Author: AstroDataHub
// ─────────────────────────────────────────────────────────────

// -------------------------------------------------------------
// CONSTANTS
// -------------------------------------------------------------
export const MU_SUN = 1.32712440018e20;   // Standard gravitational parameter of Sun (m^3/s^2)
export const MU_EARTH = 3.986004418e14;
export const MU_MOON = 4.9048695e12;
export const AU = 1.495978707e11;
export const G = 6.67430e-11;


// -------------------------------------------------------------
// BASIC ORBITAL PARAMETERS
// -------------------------------------------------------------

// semi-major axis from orbital period (Kepler's 3rd law)
export function semiMajorAxisFromPeriod(T, mu) {
    return Math.cbrt((mu * (T ** 2)) / (4 * Math.PI ** 2));
}

// Orbital period
export function orbitalPeriod(a, mu) {
    return 2 * Math.PI * Math.sqrt(a ** 3 / mu);
}

// Circular orbital velocity
export function circularVelocity(mu, r) {
    return Math.sqrt(mu / r);
}

// Escape velocity
export function escapeVelocity(mu, r) {
    return Math.sqrt(2 * mu / r);
}

// Specific orbital energy ε
export function specificOrbitalEnergy(mu, a) {
    return -mu / (2 * a);
}

// Semi-major axis from position + velocity (vis-viva)
export function semiMajorAxisFromVisViva(r, v, mu) {
    return 1 / ((2 / r) - (v ** 2 / mu));
}

// Vis-viva equation: v = sqrt(mu * (2/r - 1/a))
export function visViva(mu, r, a) {
    return Math.sqrt(mu * ((2 / r) - (1 / a)));
}


// -------------------------------------------------------------
// ORBITAL ANOMALIES: M, E, TRUE ANOMALY
// -------------------------------------------------------------

// Mean anomaly M = E - e sin(E)
export function meanAnomaly(E, e) {
    return E - e * Math.sin(E);
}

// Solve Kepler's equation for E using Newton iteration
export function eccentricAnomaly(M, e, tolerance = 1e-9) {
    let E = M;
    for (let i = 0; i < 50; i++) {
        const f = E - e * Math.sin(E) - M;
        const fp = 1 - e * Math.cos(E);
        const dE = -f / fp;
        E += dE;
        if (Math.abs(dE) < tolerance) break;
    }
    return E;
}

// True anomaly from E
export function trueAnomaly(E, e) {
    const numerator = Math.sqrt(1 - e ** 2) * Math.sin(E);
    const denominator = Math.cos(E) - e;
    return Math.atan2(numerator, denominator);
}


// -------------------------------------------------------------
// ORBIT GEOMETRY
// -------------------------------------------------------------

// Radial distance from anomaly
export function radiusFromAnomaly(a, e, theta) {
    return (a * (1 - e ** 2)) / (1 + e * Math.cos(theta));
}

// Orbital angular momentum
export function specificAngularMomentum(mu, a, e) {
    return Math.sqrt(mu * a * (1 - e ** 2));
}

// Periapsis distance
export function periapsis(a, e) {
    return a * (1 - e);
}

// Apoapsis distance
export function apoapsis(a, e) {
    return a * (1 + e);
}


// -------------------------------------------------------------
// ΔV — MANEUVERS
// -------------------------------------------------------------

// Hohmann transfer Δv1
export function hohmannDV1(mu, r1, r2) {
    return Math.sqrt(mu / r1) * (Math.sqrt((2 * r2) / (r1 + r2)) - 1);
}

// Hohmann transfer Δv2
export function hohmannDV2(mu, r1, r2) {
    return Math.sqrt(mu / r2) * (1 - Math.sqrt((2 * r1) / (r1 + r2)));
}

// Total Hohmann Δv
export function hohmannTotalDV(mu, r1, r2) {
    return Math.abs(hohmannDV1(mu, r1, r2)) + Math.abs(hohmannDV2(mu, r1, r2));
}

// Plane change Δv
export function planeChangeDV(v, deltaI) {
    return 2 * v * Math.sin(deltaI / 2);
}


// -------------------------------------------------------------
// ORBIT DETERMINATION & POSITION
// -------------------------------------------------------------

// Position vector in orbital plane
export function positionInOrbit(a, e, E) {
    const x = a * (Math.cos(E) - e);
    const y = a * Math.sqrt(1 - e ** 2) * Math.sin(E);
    return { x, y };
}

// Velocity vector in orbital plane
export function velocityInOrbit(mu, a, e, E) {
    const v_x = (-Math.sin(E)) * Math.sqrt(mu * a) / a / (1 - e * Math.cos(E));
    const v_y = (Math.sqrt(1 - e ** 2) * Math.cos(E)) * Math.sqrt(mu * a) / a / (1 - e * Math.cos(E));
    return { v_x, v_y };
}


// -------------------------------------------------------------
// INTERPLANETARY ORBITS
// -------------------------------------------------------------

// Synodic period between two planets
export function synodicPeriod(T1, T2) {
    return 1 / Math.abs((1 / T1) - (1 / T2));
}

// Sphere of influence (Laplace formula)
export function sphereOfInfluence(a, m, M) {
    return a * Math.pow(m / M, 2 / 5);
}

// Transfer time for Hohmann
export function hohmannTime(a1, a2, mu) {
    const aT = (a1 + a2) / 2;
    return Math.PI * Math.sqrt(aT ** 3 / mu);
}


// -------------------------------------------------------------
// EXPORT DEFAULT
// -------------------------------------------------------------
export default {
    semiMajorAxisFromPeriod,
    orbitalPeriod,
    circularVelocity,
    escapeVelocity,
    specificOrbitalEnergy,
    semiMajorAxisFromVisViva,
    visViva,

    meanAnomaly,
    eccentricAnomaly,
    trueAnomaly,
    radiusFromAnomaly,
    specificAngularMomentum,
    periapsis,
    apoapsis,

    hohmannDV1,
    hohmannDV2,
    hohmannTotalDV,
    planeChangeDV,

    positionInOrbit,
    velocityInOrbit,

    synodicPeriod,
    sphereOfInfluence,
    hohmannTime
};
