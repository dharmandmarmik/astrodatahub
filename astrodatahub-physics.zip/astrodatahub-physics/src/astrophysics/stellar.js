// ─────────────────────────────────────────────────────────────
// ASTRODATAHUB — STELLAR ASTROPHYSICS (FULL RESEARCH EDITION)
// SINGLE FILE MEGAMODULE
// Contains everything from basic stellar physics to advanced,
// research-level models (structure equations, evolution,
// nuclear networks, opacity, polytropes, convection, etc.)
// Author: AstroDataHub
// ─────────────────────────────────────────────────────────────


// ==============================================================
// SECTION A: FUNDAMENTAL CONSTANTS
// ==============================================================

export const G   = 6.67430e-11;         // gravitational constant
export const C   = 2.99792458e8;        // speed of light
export const KB  = 1.380649e-23;        // Boltzmann constant
export const H   = 6.62607015e-34;      // Planck constant
export const HBAR = H / (2 * Math.PI);  // reduced Planck constant
export const SIGMA = 5.670374419e-8;    // Stefan–Boltzmann constant
export const A_RAD = 7.5657e-16;        // radiation density constant
export const NA = 6.02214076e23;        // Avogadro constant

// Particle masses
export const MP = 1.67262192369e-27;    // proton mass
export const MN = 1.67492749804e-27;    // neutron mass
export const ME = 9.1093837015e-31;     // electron mass

// Solar values
export const MSUN = 1.98847e30;
export const RSUN = 6.9634e8;
export const LSUN = 3.828e26;
export const TSUN = 5772;


// ==============================================================
// SECTION B: DIMENSIONLESS UTILITY FUNCTIONS
// ==============================================================

export function cube(x) {
    return x * x * x;
}

export function clamp(x, min, max) {
    return Math.max(min, Math.min(max, x));
}

export function expSafe(x) {
    if (x > 700) return Math.exp(700);  // avoids JS overflow
    if (x < -700) return Math.exp(-700);
    return Math.exp(x);
}

export function logSafe(x) {
    return Math.log(Math.max(1e-300, x));
}


// ==============================================================
// SECTION C: GENERAL PHYSICS UTILITIES
// ==============================================================

// Ideal gas pressure
export function pressureIdeal(rho, T, mu) {
    return (rho / (mu * MP)) * KB * T;
}

// Radiation pressure
export function pressureRadiation(T) {
    return (1/3) * A_RAD * Math.pow(T, 4);
}

// Total pressure: P = P_gas + P_rad
export function pressureTotal(rho, T, mu) {
    return pressureIdeal(rho, T, mu) + pressureRadiation(T);
}

// Sound speed: c_s = sqrt(γP / ρ)
export function soundSpeed(gamma, P, rho) {
    return Math.sqrt((gamma * P) / rho);
}

// Escape velocity
export function escapeVelocity(M, R) {
    return Math.sqrt(2 * G * M / R);
}


// ==============================================================
// SECTION D: EQUATION OF STATE — FULL (gas + radiation + degeneracy)
// ==============================================================

// Electron degeneracy pressure (non-relativistic)
export function degeneracyPressureNR(rho, Ye = 0.5) {
    const n_e = Ye * rho / MP;
    return (HBAR ** 2 / (5 * ME)) * Math.pow(3 * Math.PI * Math.PI * n_e, 5/3);
}

// Electron degeneracy pressure (relativistic)
export function degeneracyPressureRel(rho, Ye = 0.5) {
    const n_e = Ye * rho / MP;
    return (HBAR * C / 4) * Math.pow(3 * Math.PI * Math.PI * n_e, 4/3);
}

// Smooth interpolation between NR and relativistic degeneracy
export function degeneracyPressure(rho, Ye = 0.5) {
    const Pnr  = degeneracyPressureNR(rho, Ye);
    const Pr   = degeneracyPressureRel(rho, Ye);
    return Math.pow(Pnr ** 1.5 + Pr ** 1.5, 2/3); // smooth match
}

// Full EOS
export function pressureEOS(rho, T, mu = 0.61, Ye = 0.5) {
    return (
        pressureIdeal(rho, T, mu) +
        pressureRadiation(T) +
        degeneracyPressure(rho, Ye)
    );
}


// ==============================================================
// SECTION E: BASIC STELLAR RELATIONS
// ==============================================================

// Luminosity from R & T
export function luminosity(R, T) {
    return 4 * Math.PI * R * R * SIGMA * T ** 4;
}

// Effective temperature
export function effectiveTemperature(L, R) {
    return Math.pow(L / (4 * Math.PI * R * R * SIGMA), 0.25);
}

// Radius from L and T
export function radiusFromLT(L, T) {
    return Math.sqrt(L / (4 * Math.PI * SIGMA * T ** 4));
}


// ==============================================================
// SECTION F: MASS–LUMINOSITY RELATIONS
// ==============================================================

export function massLuminositySimple(M) {
    return LSUN * Math.pow(M / MSUN, 3.5);
}

export function massLuminosityAdvanced(M) {
    const m = M / MSUN;
    if (m < 0.43) return LSUN * 0.23 * Math.pow(m, 2.3);
    if (m < 2.0)  return LSUN * Math.pow(m, 4);
    if (m < 20)   return LSUN * 1.5 * Math.pow(m, 3.5);
    return LSUN * 3200 * m;
}


// ==============================================================
// SECTION G: STELLAR LIFETIMES
// ==============================================================

export function mainSequenceLifetime(M) {
    const L = massLuminosityAdvanced(M);
    return 1e10 * 3.154e7 * (M / L);
}

export function lifetimeFromML(M, L) {
    return 1e10 * 3.154e7 * (M / L);
}
// ==============================================================
// SECTION H: STELLAR STRUCTURE EQUATIONS (1D SPHERICAL)
// ==============================================================
//
// Standard four stellar structure equations:
//
// (1) dP/dr = -G M(r) ρ(r) / r²                Hydrostatic equilibrium
// (2) dM/dr = 4π r² ρ(r)                       Mass continuity
// (3) dL/dr = 4π r² ρ ε(r)                     Energy generation
// (4) dT/dr = - (3 κ ρ L) / (16π a c T³ r²)    Radiative gradient
//
// Convection condition handled via Schwarzschild criterion.
//
// ==============================================================


// Basic structure derivatives ---------------------------------

export function dPdr(r, M, rho) {
    return -(G * M * rho) / (r * r);
}

export function dMdr(r, rho) {
    return 4 * Math.PI * r * r * rho;
}

export function dLdr(r, rho, epsilon) {
    return 4 * Math.PI * r * r * rho * epsilon;
}

export function dTdr_radiative(r, rho, L, T, opacity) {
    return -(3 * opacity * rho * L) /
           (16 * Math.PI * A_RAD * C * Math.pow(T, 3) * r * r);
}


// Schwarzschild criterion --------------------------------------
// If ∇_rad > ∇_ad → convection
export function isConvective(grad_radiative, grad_adiabatic = 0.4) {
    return grad_radiative > grad_adiabatic;
}


// ==============================================================
// SECTION I: POLYTROPIC MODELS & LANE–EMDEN SOLVER
// ==============================================================
//
// Polytrope:  P = K ρ^(1 + 1/n)
// Lane-Emden: (1/ξ²) d/dξ( ξ² dθ/dξ ) = -θ^n
//
// We solve using a simple RK4 ODE solver.
//
// ==============================================================


// Lane–Emden differential system: dθ/dξ, dφ/dξ
export function laneEmdenDerivatives(xi, y, n) {
    const [theta, phi] = y;
    if (xi === 0) return [0, 0]; // avoid divide-by-zero (handled in step)
    return [
        phi,
        - (xi * xi * Math.pow(theta, n) + 2 * xi * phi) / (xi * xi)
    ];
}


// RK4 integration for Lane–Emden ------------------------------
export function integrateLaneEmden(n, xiMax = 20, step = 1e-3) {
    let xi = step;
    let theta = 1;
    let phi = 0;

    const results = [{ xi: 0, theta: 1, phi: 0 }];

    while (xi < xiMax && theta > 0) {

        const y = [theta, phi];

        const k1 = laneEmdenDerivatives(xi, y, n);
        const k2 = laneEmdenDerivatives(xi + step/2, y.map((v,i)=>v+step*k1[i]/2), n);
        const k3 = laneEmdenDerivatives(xi + step/2, y.map((v,i)=>v+step*k2[i]/2), n);
        const k4 = laneEmdenDerivatives(xi + step,   y.map((v,i)=>v+step*k3[i]  ), n);

        theta += (step / 6) * (k1[0] + 2*k2[0] + 2*k3[0] + k4[0]);
        phi   += (step / 6) * (k1[1] + 2*k2[1] + 2*k3[1] + k4[1]);

        xi += step;

        results.push({ xi, theta, phi });
    }

    return results;
}


// Extract stellar properties from Lane–Emden solution ----------
export function polytropeProperties(n, centralDensity, K, xi1, dthetadxi1) {
    const a = Math.sqrt(((n + 1) * K) / (4 * Math.PI * G * Math.pow(centralDensity, 1 - 1/n)));

    const R = a * xi1;
    const M = 4 * Math.PI * a ** 3 * centralDensity * (-xi1 * xi1 * dthetadxi1);

    return { radius: R, mass: M };
}


// Predefined polytrope: n = 3 (relativistic degenerate core)
export function polytropeN3(centralDensity, K = 1e13) {
    const sol = integrateLaneEmden(3);
    const xi1 = sol[sol.length - 1].xi;
    const dthetadxi1 = sol[sol.length - 1].phi;
    return polytropeProperties(3, centralDensity, K, xi1, dthetadxi1);
}


// ==============================================================
// SECTION J: OPACITY MODELS
// ==============================================================
//
// Includes:
//  - Kramers opacity
//  - Thomson scattering
//  - H⁻ opacity
//  - Free–free + bound–free
//  - Full Rosseland harmonic combination
//
// ==============================================================


// Kramers (bound-free + free-free)
export function opacityKramers(rho, T) {
    return 4e25 * rho * Math.pow(T, -3.5);
}

// Thomson scattering
export function opacityThomson(Ye = 0.5) {
    const sigmaT = 6.6524587158e-29;
    return Ye * sigmaT / MP;
}

// H⁻ opacity (cool stars)
export function opacityHMinus(rho, T) {
    return 1e-29 * rho * Math.pow(T, 9);
}

// Combined Rosseland mean opacity
export function opacityRosseland(rho, T, Ye = 0.5) {
    const k_ff = opacityKramers(rho, T);
    const k_es = opacityThomson(Ye);
    const k_hm = opacityHMinus(rho, T);
    return (k_ff + k_es + k_hm); // simple additive approx
}
// ==============================================================
// SECTION K: NUCLEAR FUSION NETWORKS
// ==============================================================
//
// We include simplified but physically meaningful formulas for:
//
//  • Proton–Proton (PP) chain
//  • CNO cycle
//  • Triple-Alpha (He → C)
//  • Carbon burning
//  • Neon burning
//  • Oxygen burning
//  • Silicon burning (quasi NSE approximation)
//
// Rates are approximate analytic fits used in stellar evolution
// teaching/research codes (e.g., Kippenhahn & Weigert style).
//
// ==============================================================


// --------------------------------------------------------------
// Helper: Gamow peak exponential factor
// --------------------------------------------------------------
export function gamowFactor(T, Z1, Z2, mu) {
    // T in Kelvin, mu = reduced mass in amu
    const T6 = T / 1e6;
    const b = 31.29 * Z1 * Z2 * Math.sqrt(mu); // standard coefficient
    return Math.exp(-b / Math.sqrt(T6));
}



// --------------------------------------------------------------
// PP CHAIN REACTION RATE
// --------------------------------------------------------------
//
// ε_pp ≈ 1.07e-7 * ρ * X² * T6⁴
//
export function ppChainEnergyRate(rho, T, X = 0.7) {
    const T6 = T / 1e6;
    return 1.07e-7 * rho * X * X * Math.pow(T6, 4);
}



// --------------------------------------------------------------
// CNO CYCLE RATE (dominates in M > 1.3 Msun)
//
// ε_CNO ≈ 8.24e-26 * ρ * X * X_CNO * T6^20
//
export function cnoEnergyRate(rho, T, X = 0.7, Xcno = 0.01) {
    const T6 = T / 1e6;
    return 8.24e-26 * rho * X * Xcno * Math.pow(T6, 20);
}



// --------------------------------------------------------------
// TRIPLE-ALPHA PROCESS (He → C)
//
// ε_3α ≈ 5.1e8 ρ² Y³ T8^-3 exp(-4.4027/T8)
//
// where T8 = T / 1e8
//
export function tripleAlphaRate(rho, T, Y = 1.0) {
    const T8 = T / 1e8;
    return 5.1e8 * rho * rho * Math.pow(Y, 3) *
           Math.pow(T8, -3) *
           Math.exp(-4.4027 / T8);
}



// --------------------------------------------------------------
// CARBON BURNING (C + C → Ne + Mg + α …)
//
// ε_C ≈ 4.8e26 ρ X_C² T9^(29) exp(-84.165 / T9^(1/3))
//
// T9 = T / 1e9
//
export function carbonBurningRate(rho, T, Xc = 0.5) {
    const T9 = T / 1e9;
    return 4.8e26 * rho * Xc * Xc *
           Math.pow(T9, 29) *
           Math.exp(-84.165 / Math.pow(T9, 1/3));
}



// --------------------------------------------------------------
// NEON BURNING (photodisintegration-driven)
// 
// ε_Ne ≈ 3e27 * ρ * X_Ne * T9^20
//
export function neonBurningRate(rho, T, Xne = 0.3) {
    const T9 = T / 1e9;
    return 3e27 * rho * Xne * Math.pow(T9, 20);
}



// --------------------------------------------------------------
// OXYGEN BURNING
//
// ε_O ≈ 5e26 * ρ * X_O² * T9^32 exp(-70 / T9^(1/3))
//
export function oxygenBurningRate(rho, T, Xo = 0.6) {
    const T9 = T / 1e9;
    return 5e26 * rho * Xo * Xo *
           Math.pow(T9, 32) *
           Math.exp(-70 / Math.pow(T9, 1/3));
}



// --------------------------------------------------------------
// SILICON BURNING (QSE/NSE APPROXIMATION)
// 
// Silicon burning reaches quasi-nuclear statistical equilibrium.
// We use a very simplified rate:
//
// ε_Si ≈ 1e25 ρ T9^45
//
export function siliconBurningRate(rho, T) {
    const T9 = T / 1e9;
    return 1e25 * rho * Math.pow(T9, 45);
}



// --------------------------------------------------------------
// TOTAL FUSION ENERGY RATE (all channels)
// --------------------------------------------------------------
export function fusionEnergyTotal(rho, T, comp = {}) {

    const {
        X = 0.7,     // Hydrogen
        Y = 0.28,    // Helium
        Xcno = 0.01,
        Xc = 0.5,
        Xne = 0.3,
        Xo = 0.4
    } = comp;

    return (
        ppChainEnergyRate(rho, T, X) +
        cnoEnergyRate(rho, T, X, Xcno) +
        tripleAlphaRate(rho, T, Y) +
        carbonBurningRate(rho, T, Xc) +
        neonBurningRate(rho, T, Xne) +
        oxygenBurningRate(rho, T, Xo) +
        siliconBurningRate(rho, T)
    );
}
// ---------------------------------------------------------
// 9. STELLAR ATMOSPHERES & RADIATIVE TRANSFER
// ---------------------------------------------------------

/**
 * Planck’s law for blackbody spectrum:
 * B(λ, T)
 */
export function planck(lambda, T) {
    const numerator = 2 * h * c * c / Math.pow(lambda, 5);
    const denom = Math.exp((h * c) / (lambda * kB * T)) - 1;
    return numerator / denom;
}

/**
 * Flux from blackbody:
 * F = σ T^4
 */
export function blackbodyFlux(T) {
    return sigma * Math.pow(T, 4);
}

/**
 * Radiative transfer equation (formal solution):
 * I(τ) = I0 e^{-τ} + ∫ S(t) e^{-(τ-t)} dt
 * Here using simple source = constant
 */
export function radiativeIntensity(I0, tau, S) {
    return I0 * Math.exp(-tau) + S * (1 - Math.exp(-tau));
}


// ---------------------------------------------------------
// 10. OPACITY LAWS
// ---------------------------------------------------------

/**
 * Kramers opacity:
 * κ ∝ ρ T^{-3.5}
 */
export function kramersOpacity(rho, T) {
    const k0 = 4e25; // approximate coefficient (SI)
    return k0 * rho * Math.pow(T, -3.5);
}

/**
 * Electron scattering opacity (Thomson):
 * κ_es = 0.2 (1 + X)
 */
export function electronScatteringOpacity(X = 0.7) {
    return 0.2 * (1 + X);
}

/**
 * H- opacity (dominant in cool stars)
 * κ_Hminus ∝ ρ^0.5 T^9
 */
export function hMinusOpacity(rho, T) {
    return 1e-26 * Math.pow(rho, 0.5) * Math.pow(T, 9);
}


// ---------------------------------------------------------
// 11. SPECTRAL LINES, BROADENING & PROFILES
// ---------------------------------------------------------

/**
 * Doppler broadening width (thermal):
 * Δλ_D = λ * sqrt(2kT/(mc^2))
 */
export function dopplerWidth(lambda, T, mass) {
    return lambda * Math.sqrt((2 * kB * T) / (mass * c * c));
}

/**
 * Natural Lorentzian broadening:
 * L(Δλ) = (γ/π) / (Δλ² + γ²)
 */
export function lorentzProfile(deltaLambda, gamma) {
    return (gamma / Math.PI) / (deltaLambda*deltaLambda + gamma*gamma);
}

/**
 * Gaussian Doppler profile:
 */
export function gaussianProfile(deltaLambda, sigma) {
    return (1 / (sigma * Math.sqrt(2 * Math.PI)))
         * Math.exp(-0.5 * Math.pow(deltaLambda / sigma, 2));
}

/**
 * Voigt profile (approximation)
 */
export function voigtProfile(deltaLambda, sigma, gamma) {
    const fG = gaussianProfile(deltaLambda, sigma);
    const fL = lorentzProfile(deltaLambda, gamma);
    return 0.5 * (fG + fL);
}


// ---------------------------------------------------------
// 12. LIMB DARKENING MODELS
// ---------------------------------------------------------

/**
 * Linear limb darkening law:
 * I(μ) = I0 (1 - u (1 - μ))
 */
export function limbDarkeningLinear(mu, u=0.6) {
    return 1 - u * (1 - mu);
}

/**
 * Quadratic limb darkening:
 * I(μ) = 1 - a(1-μ) - b(1-μ)^2
 */
export function limbDarkeningQuadratic(mu, a=0.3, b=0.3) {
    return 1 - a*(1-mu) - b*Math.pow(1-mu,2);
}


// ---------------------------------------------------------
// 13. STELLAR WINDS & MASS LOSS
// ---------------------------------------------------------

/**
 * Escape velocity:
 * v_esc = sqrt(2GM/R)
 */
export function escapeVelocity(M, R) {
    return Math.sqrt(2 * G * M / R);
}

/**
 * Radiation-driven winds (CAK model simplified):
 * Ṁ ∝ L^1.5 M^{-1} v_∞^{-1}
 */
export function massLossCAK(L, M, vInf) {
    const C = 1e-7;
    return C * Math.pow(L,1.5) / (M * vInf);
}

/**
 * Solar wind density at distance r:
 * ρ = Ṁ / (4π r^2 v)
 */
export function windDensity(mdot, r, v) {
    return mdot / (4 * Math.PI * r*r * v);
}


// ---------------------------------------------------------
// 14. ROTATION, ANGULAR MOMENTUM, OBLATENESS
// ---------------------------------------------------------

/**
 * Angular momentum:
 * J = I ω
 */
export function angularMomentum(I, omega) {
    return I * omega;
}

/**
 * Stellar moment of inertia (polytropic approximation):
 * I = k M R^2
 * k ~ 0.2 for Sun-like stars
 */
export function momentOfInertia(M, R, k=0.2) {
    return k * M * R * R;
}

/**
 * Critical breakup rotation speed:
 * v_crit = sqrt(GM/R)
 */
export function criticalRotation(M, R) {
    return Math.sqrt(G * M / R);
}

/**
 * Oblateness (R_equator - R_pole)/R_equator
 * f ≈ (v² R_equator)/(2GM)
 */
export function stellarOblateness(v, R, M) {
    return (v*v * R) / (2 * G * M);
}
// ---------------------------------------------------------
// 15. ASTEROSEISMOLOGY — p-modes, g-modes, mixed modes
// ---------------------------------------------------------

/**
 * Large frequency separation (Δν):
 * Δν ∝ sqrt(ρ_mean)
 *   Δν ≈ (M/Msun)^0.5 / (R/Rsun)^1.5 * 135 μHz
 */
export function largeFrequencySeparation(M, R) {
    return 135e-6 * Math.sqrt(M / MSUN) / Math.pow(R / RSUN, 1.5);
}

/**
 * Frequency of maximum power for solar-like oscillations:
 * ν_max ∝ g / sqrt(T_eff)
 */
export function nuMax(g, Teff) {
    const gSun = 274;               // m/s²
    const TeffSun = 5772;          // K
    return (g / gSun) * Math.sqrt(TeffSun / Teff) * 3100e-6;
}

/**
 * p-mode frequency approximation:
 * ν_n,l ≈ Δν (n + l/2 + ε)
 */
export function pModeFrequency(n, l, deltaNu, epsilon=1.5) {
    return deltaNu * (n + l/2 + epsilon);
}

/**
 * g-mode period spacing (ΔP):
 * ΔP ∝ 1 / sqrt(N_profile)
 * N = Brunt-Väisälä frequency
 */
export function gModePeriodSpacing(Nint, L) {
    return 2 * Math.PI * Math.PI / Math.sqrt(Nint * L);
}

/**
 * Approximate Brunt–Väisälä frequency:
 * N² = (g/H_p)(∇_ad - ∇)
 */
export function bruntVaisalaFrequency(g, Hp, nablaAd, nabla) {
    return (g / Hp) * (nablaAd - nabla);
}


// ---------------------------------------------------------
// 16. HELIOSEISMOLOGY — Sun’s internal structure
// ---------------------------------------------------------

/**
 * Acoustic cutoff frequency:
 * ν_ac ≈ c / (4H)
 */
export function acousticCutoffFrequency(soundSpeed, scaleHeight) {
    return soundSpeed / (4 * scaleHeight);
}

/**
 * Sound speed profile:
 * c = sqrt(γ P / ρ)
 */
export function soundSpeed(gamma, P, rho) {
    return Math.sqrt(gamma * P / rho);
}

/**
 * Solar rotation rate splitting:
 * δν = m * Ω / (2π)
 */
export function rotationalSplitting(m, Omega) {
    return m * Omega / (2 * Math.PI);
}


// ---------------------------------------------------------
// 17. STELLAR PULSATION THEORY
// ---------------------------------------------------------

/**
 * Pulsation constant Q:
 * Q = P * sqrt(ρ / ρsun)
 */
export function pulsationConstant(P, rho, rhoSun = 1408) {
    return P * Math.sqrt(rho / rhoSun);
}

/**
 * Fundamental radial mode period:
 * P0 ≈ Q * (R/Rsun)^1.5 / (M/Msun)^0.5
 */
export function fundamentalRadialPeriod(Q, M, R) {
    return Q * Math.pow(R / RSUN, 1.5) / Math.sqrt(M / MSUN);
}

/**
 * Growth rate of pulsation (κ-mechanism):
 * γ ∝ (κ_T - κ_ρ) * (δT/T)
 */
export function pulsationGrowthRate(kappaT, kappaRho, deltaT_over_T) {
    return (kappaT - kappaRho) * deltaT_over_T;
}


// ---------------------------------------------------------
// 18. INSTABILITY STRIPS (Cepheids, RR Lyrae, Delta Scuti)
// ---------------------------------------------------------

/**
 * Classical Instability Strip edges (approx):
 * Blue edge: log(T_eff) ~ 3.9
 * Red edge:  log(T_eff) ~ 3.76
 */

export function instabilityStripClass(Teff, L) {
    const logT = Math.log10(Teff);

    if (logT > 3.9) return "Stable (Blue side)";
    if (logT < 3.76) return "Stable (Red side)";

    if (L > 1000 * LSUN) return "Cepheid Instability Strip";
    if (L > 40 * LSUN) return "RR Lyrae Instability Strip";
    return "Delta Scuti Instability Strip";
}


// ---------------------------------------------------------
// 19. NON-RADIAL OSCILLATION MODES
// ---------------------------------------------------------

/**
 * Spherical harmonic mode identification:
 * l = 0 → radial
 * l = 1 → dipole
 * l = 2 → quadrupole, etc.
 */
export function oscillationModeType(l) {
    if (l === 0) return "Radial mode";
    if (l === 1) return "Dipole mode";
    if (l === 2) return "Quadrupole mode";
    return `Non-radial mode (l=${l})`;
}

/**
 * Mode inertia:
 * I ∝ ∫ ξ² ρ r² dr
 * (Simplified scaling)
 */
export function modeInertia(amplitude, rho, r) {
    return amplitude * amplitude * rho * r * r;
}
// ---------------------------------------------------------
// 20. PRE-MAIN-SEQUENCE EVOLUTION
// ---------------------------------------------------------

/**
 * Kelvin–Helmholtz timescale:
 * t_KH = GM^2 / (RL)
 */
export function kelvinHelmholtzTimescale(M, R, L) {
    return (G * M * M) / (R * L);
}

/**
 * Protostellar radius scaling (approx empirical):
 * R ≈ 3 R_sun (M/M_sun)^0.5 during early PMS
 */
export function protostarRadius(M) {
    return 3 * RSUN * Math.sqrt(M / MSUN);
}

/**
 * Hayashi track temperature:
 * Fully convective stars stay near constant T_eff ≈ 3000–4500 K
 */
export function hayashiTemperature(M) {
    return 3500 + 350 * Math.log10(M / MSUN);
}

/**
 * Henyey track luminosity scaling:
 * L ∝ M^2 (for intermediate-mass PMS)
 */
export function henyeyLuminosity(M) {
    return LSUN * Math.pow(M / MSUN, 2);
}

/**
 * Onset of hydrogen burning (ZAMS threshold):
 * Occurs when central T ~ 1e7 K
 */
export function zamsTemperature() {
    return 1e7;
}

/**
 * ZAMS luminosity relation:
 * L_ZAMS ≈ L_sun * (M/M_sun)^4
 */
export function zamsLuminosity(M) {
    return LSUN * Math.pow(M / MSUN, 4);
}


// ---------------------------------------------------------
// 21. RED GIANT BRANCH (RGB) EVOLUTION
// ---------------------------------------------------------

/**
 * Core mass–luminosity relation for RGB:
 * L ∝ M_core^7
 */
export function rgbLuminosity(Mcore) {
    return LSUN * Math.pow(Mcore / (0.45 * MSUN), 7);
}

/**
 * Radius expansion on RGB:
 * R ≈ 100 R_sun * (L/1000L_sun)^0.5
 */
export function rgbRadius(L) {
    return 100 * RSUN * Math.sqrt(L / (1000 * LSUN));
}

/**
 * Hydrogen shell-burning temperature:
 * T_shell ≈ 4e7 K
 */
export function shellBurningTemperature() {
    return 4e7;
}

/**
 * Electron degeneracy pressure in helium core
 * (core becomes supported by degeneracy, T increases without expansion)
 */
export function degenerateCorePressure(rho) {
    return 1.2e13 * Math.pow(rho / 1e6, 5/3);
}

/**
 * RGB tip luminosity (helium flash point)
 * ~2000–3000 L_sun
 */
export function rgbTipLuminosity() {
    return 2500 * LSUN;
}


// ---------------------------------------------------------
// 22. HELIUM FLASH (LOW-MASS STARS)
// ---------------------------------------------------------

/**
 * Helium ignition temperature:
 * T_He ≈ 1e8 K
 */
export function heliumIgnitionTemperature() {
    return 1e8;
}

/**
 * Energy released in helium flash:
 * E ≈ 10^44 J
 */
export function heliumFlashEnergy() {
    return 1e44;
}

/**
 * Core mass at helium flash (nearly constant):
 * M_core,flash ≈ 0.48 M_sun
 */
export function heliumFlashCoreMass() {
    return 0.48 * MSUN;
}

/**
 * Density at which triple alpha runaway becomes explosive:
 */
export function tripleAlphaCriticalDensity() {
    return 1e6;  // kg/m³
}


// ---------------------------------------------------------
// 23. HORIZONTAL BRANCH (HB) & RED CLUMP
// ---------------------------------------------------------

/**
 * HB luminosity:
 * L_HB ≈ 50 L_sun for low-mass stars
 */
export function horizontalBranchLuminosity(M) {
    return 50 * LSUN * (M / MSUN);
}

/**
 * HB effective temperature:
 * Depends strongly on envelope mass
 */
export function horizontalBranchTemperature(envMass) {
    if (envMass < 0.02 * MSUN) return 20000; // Blue HB
    if (envMass < 0.1  * MSUN) return 9000;
    return 5500; // Red clump / red HB
}

/**
 * Core helium burning lifetime:
 * t_He ≈ 100 Myr
 */
export function heliumBurningLifetime() {
    return 1e8 * 3.154e7;
}


// ---------------------------------------------------------
// 24. ADVANCED SHELL BURNING (He shell + H shell)
// ---------------------------------------------------------

/**
 * Helium-burning luminosity:
 * L_He ∝ T^40 (very temperature-sensitive)
 */
export function heliumBurningLuminosity(T) {
    return 1e-8 * Math.pow(T / 1e8, 40);
}

/**
 * H-shell and He-shell energy generation ratio:
 */
export function shellEnergyRatio(T_H, T_He) {
    const H = ppChainRate(T_H);
    const He = 1e-8 * Math.pow(T_He / 1e8, 40);
    return H / He;
}

/**
 * Growth of degenerate C–O core:
 * dM/dt ≈ shell luminosity / (epsilon)
 */
export function coreGrowthRate(Lshell, epsilon = 6e13) {
    return Lshell / epsilon;
}


// ---------------------------------------------------------
// 25. RED CLUMP POSITIONING (asteroseismic calibration)
// ---------------------------------------------------------

/**
 * Red clump (RC) stars have nearly fixed luminosities:
 */
export function redClumpLuminosity() {
    return 50 * LSUN;
}

/**
 * Red clump temperature range:
 */
export function redClumpTemperature() {
    return { min: 4500, max: 5200 };
}
/***************************************************************************************************
 * PART 7 — EXTREME HIGH-LEVEL MODULES FOR STELLAR ASTROPHYSICS
 * These push toward NASA-grade physics, with full research-quality algorithms.
 ***************************************************************************************************/


/***************************************************************************************************
 * 1. ADVANCED OPACITIES — κ(ρ, T, composition)
 * Includes:
 *   - Bound–Bound (lines)
 *   - Bound–Free (photoionization)
 *   - Free–Free (Bremsstrahlung)
 *   - Thomson + Compton scattering
 ***************************************************************************************************/

export function electronScatteringOpacity(X) {
    // X = hydrogen mass fraction
    return 0.2 * (1 + X);
}

export function freeFreeOpacity(rho, T, Z) {
    return 3.68e22 * (1 - Z) * (rho) * T ** (-3.5);
}

export function boundFreeOpacity(rho, T, Z) {
    return 4.34e25 * Z * rho * T ** (-3.5);
}

export function lineOpacity(T, rho, ionization) {
    return 1e-24 * ionization * rho * Math.sqrt(T);
}

export function totalOpacity(rho, T, X, Z, ionization) {
    return (
        electronScatteringOpacity(X) +
        freeFreeOpacity(rho, T, Z) +
        boundFreeOpacity(rho, T, Z) +
        lineOpacity(T, rho, ionization)
    );
}


/***************************************************************************************************
 * 2. NON-LTE RADIATIVE TRANSFER (2-LEVEL ATOM APPROXIMATION)
 ***************************************************************************************************/

export function nonLTESourceFunction(B, epsilon) {
    // S = (1 - ε) * J + ε * B  ; approximate J ≈ B for LTE deviations
    return epsilon * B + (1 - epsilon) * B;
}

export function opticalDepth(kappa, rho, ds) {
    return kappa * rho * ds;
}

export function radiativeTransferIntensity(I0, S, tau) {
    return I0 * Math.exp(-tau) + S * (1 - Math.exp(-tau));
}


/***************************************************************************************************
 * 3. CONVECTION — MIXING-LENGTH THEORY (MLT & MLT++)
 ***************************************************************************************************/

export function mixingLengthPressureScaleHeight(P, rho, g) {
    return P / (rho * g);
}

export function mixingLengthVelocity(g, delta, Hp, grad, grad_ad, mixingLength) {
    const driving = g * delta * (grad - grad_ad) * Hp;
    return Math.sqrt(Math.max(driving, 0)) * mixingLength;
}

export function convectiveFlux(rho, cp, T, v_conv, grad, grad_ad) {
    return rho * cp * T * v_conv * (grad - grad_ad);
}

export function MLTplusplus(grad, grad_ad, radiationPressureFraction) {
    return grad + radiationPressureFraction * Math.abs(grad - grad_ad);
}


/***************************************************************************************************
 * 4. NUCLEAR NETWORK — ADVANCED REACTIONS
 * We include:
 *   - pp-chain (pp → D + ...)
 *   - CNO cycle
 *   - Triple-alpha
 *   - Carbon burning
 *   - Oxygen burning
 *   - Silicon burning
 ***************************************************************************************************/

// pp-chain rate
export function ppChainRate(rho, X, T) {
    const T6 = T / 1e6;
    return 4e-15 * (rho * X**2) * T6 ** 4;
}

// CNO cycle
export function cnoRate(rho, X, Z, T) {
    const T6 = T / 1e6;
    return 8e-31 * rho * X * Z * T6 ** 20;
}

// triple-alpha
export function tripleAlphaRate(rho, Y, T) {
    return 5e8 * rho**2 * Y**3 * Math.exp(-44 / (T / 1e8));
}

// advanced burning (very approximate)
export function carbonBurningRate(rho, T) {
    const T9 = T / 1e9;
    return 1e-12 * rho**2 * T9 ** 29;
}

export function oxygenBurningRate(rho, T) {
    const T9 = T / 1e9;
    return 1e-8 * rho**2 * T9 ** 33;
}

export function siliconBurningRate(rho, T) {
    const T9 = T / 1e9;
    return 5e-5 * rho**2 * T9 ** 45;
}

// Total nuclear power
export function totalNuclearLuminosity(rho, T, X, Y, Z) {
    return (
        ppChainRate(rho, X, T) +
        cnoRate(rho, X, Z, T) +
        tripleAlphaRate(rho, Y, T) +
        carbonBurningRate(rho, T) +
        oxygenBurningRate(rho, T) +
        siliconBurningRate(rho, T)
    );
}


/***************************************************************************************************
 * 5. NEUTRINO EMISSION PROCESSES
 * Includes:
 *   - Pair annihilation
 *   - Photo-neutrinos
 *   - Plasma neutrinos
 *   - Bremsstrahlung neutrinos
 ***************************************************************************************************/

// Neutrino loss from pair annihilation
export function neutrinoPairLoss(T) {
    return 1e-24 * T ** 9;
}

// plasma neutrinos
export function neutrinoPlasmaLoss(rho, T) {
    return 1e-36 * rho * T ** 6;
}

// bremsstrahlung neutrinos
export function neutrinoBremsLoss(rho, T) {
    return 1e-39 * rho**2 * T ** 5;
}

export function totalNeutrinoLoss(rho, T) {
    return neutrinoPairLoss(T) +
           neutrinoPlasmaLoss(rho, T) +
           neutrinoBremsLoss(rho, T);
}


/***************************************************************************************************
 * 6. EXTENDED EQUATION OF STATE
 * Includes degeneracy + radiation pressure + partial ionization
 ***************************************************************************************************/

export function degeneracyPressure(rho, Y_e) {
    return 1e13 * (rho * Y_e) ** (5/3);
}

export function radiationPressure(T) {
    return (1/3) * 7.5657e-16 * T ** 4;
}

export function totalPressure(rho, T, X, Y_e) {
    const gas = rho * 8.314e7 * T / (1 + X); 
    const deg = degeneracyPressure(rho, Y_e);
    const rad = radiationPressure(T);
    return gas + deg + rad;
}


/***************************************************************************************************
 * 7. BINARY STAR PHYSICS — ROCHE LOBE, MASS TRANSFER
 ***************************************************************************************************/

export function rocheLobeRadius(a, q) {
    // Eggleton formula
    return a * (0.49 * q**(2/3)) / (0.6 * q**(2/3) + Math.log(1 + q**(1/3)));
}

export function massTransferRate(M_donor, R_donor, R_lobe, scaleHeight) {
    const overflow = (R_donor - R_lobe) / scaleHeight;
    return Math.max(0, 1e-9 * M_donor * Math.exp(overflow));
}


/***************************************************************************************************
 * 8. INTERNAL MIXING, ROTATION, AND ANGULAR MOMENTUM TRANSPORT
 ***************************************************************************************************/

export function rotationalVelocity(R, omega) {
    return R * omega;
}

export function centrifugalAcceleration(R, omega) {
    return R * omega ** 2;
}

export function EddingtonSweetCirculation(omega, L, M, R) {
    return (omega**2 * R**3) / (G * M) * (L / M);
}

export function shearInstabilityDiffusion(dOmega_dr, rho, K) {
    return K * (dOmega_dr ** 2) / Math.sqrt(rho);
}

export function totalDiffusionCoefficient(D_shear, D_meridional, D_conv) {
    return D_shear + D_meridional + D_conv;
}

/***************************************************************************************************
 * PART 8 — ADVANCED HYDRODYNAMICS & SUPERNOVA / COLLAPSE PHYSICS
 ***************************************************************************************************/


/***************************************************************************************************
 * 1. HYDRODYNAMICS — EULER EQUATIONS (1D SPHERICAL)
 *
 * Continuity:    ∂ρ/∂t + 1/r² ∂(r² ρ v)/∂r = 0
 * Momentum:      ∂(ρv)/∂t + 1/r² ∂(r²(ρv² + P))/∂r = - ρ GM(r)/r²
 * Energy:        ∂E/∂t + 1/r² ∂(r² (v(E+P))) = - cooling + heating
 *
 ***************************************************************************************************/

export function eulerUpdate(rho, v, P, E, dr, dt, M_enclosed) {
    const n = rho.length;

    let rho_new = new Array(n).fill(0);
    let v_new   = new Array(n).fill(0);
    let P_new   = new Array(n).fill(0);
    let E_new   = new Array(n).fill(0);

    for (let i = 1; i < n - 1; i++) {
        const r = (i + 0.5) * dr;

        const flux_rho =
            - (1 / r**2) * ((r**2 * rho[i] * v[i] - (r - dr)**2 * rho[i-1] * v[i-1]) / dr);

        const flux_mom =
            - (1 / r**2) * ((r**2 * (rho[i] * v[i]**2 + P[i]) -
                (r - dr)**2 * (rho[i-1] * v[i-1]**2 + P[i-1])) / dr)
              - rho[i] * G * M_enclosed[i] / (r**2);

        const flux_energy =
            - (1 / r**2) * (
                r**2 * v[i] * (E[i] + P[i]) -
                (r - dr)**2 * v[i-1] * (E[i-1] + P[i-1])
            ) / dr;

        rho_new[i] = rho[i] + dt * flux_rho;
        v_new[i]   = v[i] + dt * flux_mom / rho[i];
        E_new[i]   = E[i] + dt * flux_energy;
    }

    return { rho: rho_new, v: v_new, E: E_new };
}


/***************************************************************************************************
 * 2. SHOCK-CAPTURE (RIEMANN SOLVER — APPROXIMATE)
 ***************************************************************************************************/

export function riemannSolver(left, right) {
    // Toro’s approximate solver (very simplified)
    const rhoL = left.rho;
    const uL   = left.v;
    const pL   = left.P;

    const rhoR = right.rho;
    const uR   = right.v;
    const pR   = right.P;

    const aL = Math.sqrt(1.4 * pL / rhoL);
    const aR = Math.sqrt(1.4 * pR / rhoR);

    const u_star = (uL + uR) / 2 - (pR - pL) / (2 * (aL + aR));
    const p_star = (pL + pR) / 2 - (aL * (uR - uL)) / 2;

    return { u_star, p_star };
}


/***************************************************************************************************
 * 3. RADIATION HYDRODYNAMICS — (DIFFUSION APPROXIMATION)
 ***************************************************************************************************/

export function radiationDiffusion(L, r, kappa, rho) {
    return L / (4 * Math.PI * r**2 * c * rho * kappa);
}

export function radiativeAcceleration(kappa, rho, F) {
    return kappa * F / c;
}


/***************************************************************************************************
 * 4. CORE COLLAPSE PHYSICS
 * Includes:
 *   - Electron capture (reducing Ye)
 *   - Neutrino trapping
 *   - Core bounce at nuclear density
 ***************************************************************************************************/

// electron capture rate
export function electronCaptureRate(rho, Y_e, T) {
    return 1e-4 * rho * Y_e * Math.exp(-1.2e10 / T);
}

// decrease in Ye per second
export function updateYe(Y_e, rho, T, dt) {
    return Y_e - dt * electronCaptureRate(rho, Y_e, T);
}

export function coreBouncePressure(rho) {
    if (rho < 2.7e14) return 0;
    return 3e34 * (rho / 2.7e14 - 1);  // stiff nuclear EOS
}


/***************************************************************************************************
 * 5. SUPERNOVA EXPLOSION ENERGETICS
 ***************************************************************************************************/

export function neutrinoHeatingRate(L_nu, r, kappa_nu) {
    return (L_nu * kappa_nu) / (4 * Math.PI * r**2);
}

export function explosionEnergy(massShells, velocities, dr) {
    let total = 0;
    for (let i = 0; i < massShells.length; i++) {
        total += 0.5 * massShells[i] * velocities[i]**2;
    }
    return total;
}


/***************************************************************************************************
 * 6. PAIR INSTABILITY (γ < 4/3 CRITERION)
 ***************************************************************************************************/

export function adiabaticGamma(P, rho, T) {
    const gamma_rad = 4/3;
    const gamma_gas = 5/3;

    const beta = P_gas(T, rho) / (P + 1e-20);

    return beta * gamma_gas + (1 - beta) * gamma_rad;
}

export function isPairUnstable(P, rho, T) {
    return adiabaticGamma(P, rho, T) < 4/3;
}


/***************************************************************************************************
 * 7. EQUATION OF STATE — NEUTRON STAR (POLYTROPIC + NUCLEAR)
 ***************************************************************************************************/

export function neutronStarPressure(rho) {
    // Polytropic approximation for high-density nuclear matter
    const K = 3.5e33;
    const gamma = 2.5;
    return K * rho ** gamma;
}

export function neutronStarMassRadius(rho_c) {
    const R = 10e3 * (rho_c / 1e15) ** -0.2;  // radius (m)
    const M = 2e30  * (rho_c / 1e15) ** 0.4;  // mass (kg)
    return { M, R };
}


/***************************************************************************************************
 * 8. PROTO-NEUTRON STAR COOLING
 ***************************************************************************************************/

export function neutrinoLuminosityCooling(t) {
    return 1e53 * Math.exp(-t / 3); // erg/s, decays over 3 seconds
}


/***************************************************************************************************
 * 9. MAGNETO-HYDRODYNAMICS (MHD)
 ***************************************************************************************************/

export function magneticPressure(B) {
    return B**2 / (8 * Math.PI);
}

export function alfvenSpeed(B, rho) {
    return B / Math.sqrt(4 * Math.PI * rho);
}

export function magneticBrakingTorque(B, R, Omega) {
    return B**2 * R**3 * Omega / (4 * Math.PI);
}

export function MHD_totalPressure(P, B) {
    return P + magneticPressure(B);
}


/***************************************************************************************************
 * 10. MASSIVE STAR PRE-COLLAPSE STRUCTURE
 ***************************************************************************************************/

export function ironCoreMass(M_star) {
    return 1.3 + 0.1 * Math.log(M_star / 10);
}

export function siliconShellThickness(M_star) {
    return 300 * (M_star / 20);
}


/***************************************************************************************************
 * End of PART 8 — more parts exist (PART 9, 10, 11…)
 ***************************************************************************************************/


