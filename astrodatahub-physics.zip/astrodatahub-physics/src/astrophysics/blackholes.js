/**
 * Astrophysics – Black Hole Physics
 * High-precision formulas for Schwarzschild, Kerr, evaporation,
 * accretion disks, and relativistic effects.
 */

import constants from "../constants/fundamental.js";
const { G, c, hbar, kB, mp } = constants;

/** Schwarzschild radius (m) */
export function schwarzschildRadius(M) {
  return (2 * G * M) / (c * c);
}

/** Photon sphere radius (m) */
export function photonSphereRadius(M) {
  return (3 * G * M) / (c * c);
}

/** Gravitational time dilation near Schwarzschild BH */
export function timeDilation(r, M) {
  const Rs = schwarzschildRadius(M);
  if (r <= Rs) return 0; // cannot define time dilation inside horizon
  return Math.sqrt(1 - Rs / r);
}

/** Gravitational redshift factor z near Schwarzschild BH */
export function gravitationalRedshift(r, M) {
  return 1 / timeDilation(r, M) - 1;
}

/**
 * Kerr Black Hole: ISCO radius for given spin parameter a (dimensionless, |a| ≤ 1)
 * Formula from Bardeen et al. 1972.
 */
export function kerrISCO(M, a) {
  if (Math.abs(a) > 1) throw new Error("Spin parameter 'a' must satisfy |a| ≤ 1");

  const Z1 = 1 + Math.cbrt(1 - a * a) * (Math.cbrt(1 + a) + Math.cbrt(1 - a));
  const Z2 = Math.sqrt(3 * a * a + Z1 * Z1);

  const sign = a >= 0 ? 1 : -1; // prograde vs retrograde
  const rISCO = (G * M / (c * c)) * (3 + Z2 - sign * Math.sqrt((3 - Z1) * (3 + Z1 + 2 * Z2)));

  return rISCO;
}

/** Eddington Luminosity (watts) */
export function eddingtonLuminosity(M) {
  const sigmaT = 6.6524587321e-29; // Thomson cross section
  return (4 * Math.PI * G * M * mp * c) / sigmaT;
}

/** Hawking temperature (K) */
export function hawkingTemperature(M) {
  return (hbar * c * c * c) / (8 * Math.PI * G * M * kB);
}

/** Black hole evaporation time (seconds) */
export function evaporationTime(M) {
  return (5120 * Math.PI * G * G * G * M * M * M) / (hbar * c * c * c * c);
}

/** Accretion disk efficiency (Schwarzschild BH ≈ 0.057) */
export const diskEfficiencySchwarzschild = 0.057;

/** Accretion disk efficiency (Kerr, spin a) */
export function diskEfficiencyKerr(a) {
  if (Math.abs(a) > 1) throw new Error("Spin parameter must satisfy |a| ≤ 1");

  // Efficiency = 1 - specific energy at ISCO
  // Approximation from Novikov-Thorne model
  const Z1 = 1 + Math.cbrt(1 - a * a) * (Math.cbrt(1 + a) + Math.cbrt(1 - a));
  const Z2 = Math.sqrt(3 * a * a + Z1 * Z1);
  const rISCO = 3 + Z2 - Math.sqrt((3 - Z1) * (3 + Z1 + 2 * Z2));

  const E = Math.sqrt(1 - 2 / (3 * rISCO));
  return 1 - E;
}

/** Tidal force at radius r (N/kg/m) */
export function tidalForce(M, r) {
  return (2 * G * M) / (r ** 3);
}

/** Penrose process maximum efficiency (up to 21%) */
export function penroseProcessEfficiency(a) {
  if (Math.abs(a) > 1) throw new Error("Invalid spin parameter");

  return 1 - Math.sqrt(0.5 * (1 + Math.sqrt(1 - a * a)));
}

export default {
  schwarzschildRadius,
  photonSphereRadius,
  timeDilation,
  gravitationalRedshift,
  kerrISCO,
  eddingtonLuminosity,
  hawkingTemperature,
  evaporationTime,
  diskEfficiencySchwarzschild,
  diskEfficiencyKerr,
  tidalForce,
  penroseProcessEfficiency
};
