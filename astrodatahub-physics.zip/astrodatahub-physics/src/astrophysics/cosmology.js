// ============================================================================
// COSMOLOGY MODULE — ΛCDM + ADVANCED DISTANCE CALCULATIONS
// Highly accurate cosmology utilities for redshift, H(z), distances,
// timescales, and structure-growth modeling.
// ============================================================================

// ==============================
// DEFAULT ΛCDM PARAMS (Planck18)
// ==============================
export const COSMOLOGY = {
    H0: 67.4,                   // Hubble constant (km/s/Mpc)
    Ωm: 0.315,                  // Matter density
    ΩΛ: 0.685,                  // Dark-energy density
    Ωr: 9.2e-5,                 // Radiation density (CMB photons + neutrinos)
    c: 299792.458               // Speed of light km/s
};

// Hubble parameter H(z)
export function HubbleParameter(z, params = COSMOLOGY) {
    const { H0, Ωm, ΩΛ, Ωr } = params;
    return H0 * Math.sqrt(
        Ωr * (1 + z)**4 +
        Ωm * (1 + z)**3 +
        ΩΛ
    );
}

// E(z) = H(z)/H0
export function Ez(z, params = COSMOLOGY) {
    return HubbleParameter(z, params) / params.H0;
}

// ============================================================================
// NUMERICAL INTEGRATION (SIMPSON'S RULE)
// ============================================================================
function simpsonIntegrate(func, a, b, n = 1000) {
    if (n % 2 !== 0) n += 1;
    const h = (b - a) / n;
    let sum = func(a) + func(b);

    for (let i = 1; i < n; i++) {
        const x = a + i * h;
        sum += func(x) * (i % 2 === 0 ? 2 : 4);
    }
    return (h / 3) * sum;
}

// ============================================================================
// COMOVING DISTANCE
// ============================================================================
export function comovingDistance(z, params = COSMOLOGY) {
    return params.c * simpsonIntegrate(
        zprime => 1 / HubbleParameter(zprime, params),
        0, z, 2000
    );
}

// ============================================================================
// PROPER / LIGHT-TRAVEL / ANGULAR / LUMINOSITY DISTANCES
// ============================================================================

// Light-travel distance (proper distance now)
export function lightTravelDistance(z, params = COSMOLOGY) {
    return comovingDistance(z, params);
}

// Angular-diameter distance Da
export function angularDiameterDistance(z, params = COSMOLOGY) {
    return comovingDistance(z, params) / (1 + z);
}

// Luminosity distance Dl
export function luminosityDistance(z, params = COSMOLOGY) {
    return comovingDistance(z, params) * (1 + z);
}

// Distance modulus μ
export function distanceModulus(z, params = COSMOLOGY) {
    const Dl_pc = luminosityDistance(z, params) * 1e6; // Mpc → pc
    return 5 * Math.log10(Dl_pc / 10);
}

// ============================================================================
// LOOKBACK TIME + AGE OF UNIVERSE AT REDSHIFT z
// ============================================================================
export function lookbackTime(z, params = COSMOLOGY) {
    const H0_s = params.H0 / (3.086e19); // km/s/Mpc → 1/s
    const integrand = zp => 1 / ((1 + zp) * Ez(zp, params));

    const t_H = 1 / H0_s / (3600 * 24 * 365.25 * 1e9); // Hubble time in Gyr
    return t_H * simpsonIntegrate(integrand, 0, z, 2000);
}

export function ageOfUniverseAtZ(z, params = COSMOLOGY) {
    const age0 = ageOfUniverse(params);
    return age0 - lookbackTime(z, params);
}

// Age at z = 0
export function ageOfUniverse(params = COSMOLOGY) {
    const H0_s = params.H0 / (3.086e19);
    const integrand = zp => 1 / ((1 + zp) * Ez(zp, params));

    const t_H = 1 / H0_s / (3600 * 24 * 365.25 * 1e9);
    return t_H * simpsonIntegrate(integrand, 0, 1e4, 5000);
}

// ============================================================================
// GROWTH OF STRUCTURE — LINEAR GROWTH FACTOR D(z)
// ============================================================================
export function growthFactor(z, params = COSMOLOGY) {
    const { Ωm } = params;
    const Ez_val = Ez(z, params);

    return Ez_val * simpsonIntegrate(
        zp => (1 + zp) / (Ez(zp, params))**3,
        z, Infinity, 2000
    ) * 2.5 * Ωm;
}

// ============================================================================
// COSMIC MICROWAVE BACKGROUND — BASIC FUNCTIONS
// ============================================================================
export function cmbTemperature(z) {
    return 2.7255 * (1 + z);
}

export function horizonScaleAtRecombination() {
    return 147; // Mpc — BAO sound horizon (Planck18)
}

// ============================================================================
// MATTER POWER SPECTRUM — VERY BASIC MODEL (k in h/Mpc)
// ============================================================================
export function simpleMatterPower(k, A = 1e4, n = 0.96) {
    return A * k**n * Math.exp(-k);
}

// ============================================================================
// REDSHIFT ↔ VELOCITY
// ============================================================================
export function redshiftToVelocity(z) {
    return COSMOLOGY.c * ((1 + z)**2 - 1) / ((1 + z)**2 + 1);
}

export function velocityToRedshift(v) {
    const c = COSMOLOGY.c;
    return Math.sqrt((1 + v/c) / (1 - v/c)) - 1;
}

// ============================================================================
// EXPORT DEFAULT — GROUPED
// ============================================================================
export default {
    COSMOLOGY,
    HubbleParameter,
    Ez,
    comovingDistance,
    lightTravelDistance,
    angularDiameterDistance,
    luminosityDistance,
    distanceModulus,
    lookbackTime,
    ageOfUniverseAtZ,
    ageOfUniverse,
    growthFactor,
    cmbTemperature,
    horizonScaleAtRecombination,
    simpleMatterPower,
    redshiftToVelocity,
    velocityToRedshift
};
