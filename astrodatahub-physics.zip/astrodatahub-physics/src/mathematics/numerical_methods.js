export function rk4Step(f, t, y, h) {
  const k1 = f(t,y);
  const k2 = f(t + h/2, y + (h/2)*k1);
  const k3 = f(t + h/2, y + (h/2)*k2);
  const k4 = f(t + h, y + h*k3);
  return y + (h/6)*(k1 + 2*k2 + 2*k3 + k4);
}
