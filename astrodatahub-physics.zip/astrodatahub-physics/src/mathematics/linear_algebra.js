export function dot(a, b) {
  if (a.length !== b.length) throw new Error("length mismatch");
  return a.reduce((s, v, i) => s + v * b[i], 0);
}
export function norm(a) { return Math.sqrt(dot(a,a)); }
