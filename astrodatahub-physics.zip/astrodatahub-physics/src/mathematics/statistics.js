export function mean(arr) { return arr.reduce((s,x)=>s+x,0)/arr.length; }
export function variance(arr) {
  const m = mean(arr);
  return arr.reduce((s,x)=>s+(x-m)*(x-m),0)/(arr.length-1);
}
