export function idealGasPressure(n, T, V, kB = 1.380649e-23) {
  return (n * kB * T) / V;
}

export function internalEnergyMonoatomic(N, T, kB = 1.380649e-23) {
  // U = 3/2 NkT
  return 1.5 * N * kB * T;
}
