export function boltzmannFactor(E, T, kB = 1.380649e-23) {
  return Math.exp(-E / (kB * T));
}
