export function conductionQ(k, A, dT, L) {
  return (k * A * dT) / L;
}
