export const AU = 1.495978707e11; // meters
export const pc = 3.085677581e16; // parsec in meters
export const ly = 9.4607e15; // lightyear in meters
export const M_sun = 1.98847e30; // kg
export const R_sun = 6.957e8; // m
