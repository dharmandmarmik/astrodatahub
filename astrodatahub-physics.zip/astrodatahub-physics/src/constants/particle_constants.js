export const protonMass = 1.67262192369e-27;
export const neutronMass = 1.67492749804e-27;
export const electronMass = 9.1093837015e-31;
export const elementaryCharge = 1.602176634e-19;
