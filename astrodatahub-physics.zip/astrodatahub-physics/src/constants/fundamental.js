// Fundamental physical constants (SI)
export const c = 299792458; // m/s
export const G = 6.67430e-11; // m^3 kg^-1 s^-2
export const h = 6.62607015e-34; // J s
export const hbar = h / (2 * Math.PI);
export const kB = 1.380649e-23; // J/K
export const e = 1.602176634e-19; // C
export const me = 9.1093837015e-31; // kg
export const mp = 1.67262192369e-27; // kg
