export const secondsPerDay = 86400;
export const secondsPerYear = 365.25 * secondsPerDay;
