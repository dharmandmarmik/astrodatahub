// Simple finite-difference kinetic operator for 1D grid (matrix-like returns)
export function kineticOperator(N, dx, hbar = 1.054571817e-34, m = 9.1093837015e-31) {
  // returns a tridiagonal object {diag, off} for use in simple solvers
  const coef = - (hbar*hbar) / (2 * m * dx * dx);
  const diag = new Array(N).fill(-2 * coef);
  const off = new Array(N-1).fill(coef);
  return { diag, off };
}
