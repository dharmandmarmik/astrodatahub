// very small helper: apply finite-difference Hamiltonian to vector psi
export function applyHamiltonian(psi, diag, off) {
  const N = psi.length;
  const out = new Array(N).fill(0);
  for (let i=0;i<N;i++){
    out[i] = diag[i] * psi[i];
    if (i>0) out[i] += off[i-1]*psi[i-1];
    if (i<N-1) out[i] += off[i]*psi[i+1];
  }
  return out;
}
