export const PLANCK = 6.62607015e-34;
export const HBAR = PLANCK / (2 * Math.PI);
