// stub: output data series for plotting in external tool
export function series(x, y) {
  if (x.length !== y.length) throw new Error("length mismatch");
  return { x, y };
}
