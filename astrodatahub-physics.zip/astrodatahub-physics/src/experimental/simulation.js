export function simpleEuler(f, y0, t0, h, steps) {
  let y = y0, t = t0, res = [];
  for (let i=0;i<steps;i++){
    res.push({t, y});
    y = y + h * f(t, y);
    t += h;
  }
  return res;
}
