export function movingAverage(arr, window=3) {
  const out = [];
  for (let i=0;i<=arr.length-window;i++){
    const s = arr.slice(i,i+window).reduce((a,b)=>a+b,0);
    out.push(s/window);
  }
  return out;
}
