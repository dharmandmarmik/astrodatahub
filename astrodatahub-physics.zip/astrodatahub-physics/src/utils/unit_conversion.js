import * as C from "../constants/astro_constants.js";
export function metersToAU(m) { return m / C.AU; }
export function AUToMeters(au) { return au * C.AU; }
export function metersToLy(m) { return m / C.ly; }
