// Very simple numeric parser for inputs (accepts string or number)
export function toNumber(x) {
  if (typeof x === "number") return x;
  const n = Number(x);
  if (Number.isNaN(n)) throw new Error("cannot parse number");
  return n;
}
