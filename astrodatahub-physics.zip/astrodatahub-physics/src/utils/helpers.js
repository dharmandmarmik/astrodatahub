export function clamp(x, a, b) { return Math.max(a, Math.min(b, x)); }
export function approxEqual(a, b, tol = 1e-9) { return Math.abs(a-b) <= tol; }
