export function activity(N, lambda) {
  return lambda * N;
}
