export function qValue(massInitial, massFinal) {
  // mass in kg, convert to energy E=mc^2
  const c = 299792458;
  return (massInitial - massFinal) * c * c;
}
