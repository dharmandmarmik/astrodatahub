export function radioactiveDecay(N0, lambda, t) {
  return N0 * Math.exp(-lambda * t);
}
export function halfLifeToLambda(tHalf) {
  return Math.log(2) / tHalf;
}
